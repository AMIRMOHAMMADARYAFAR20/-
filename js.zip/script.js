'use strict';
const diceEl = document.querySelector(".dice");
const rolldiceEl = document.querySelector(".btn--roll");
const current0 = document.querySelector("#current--0");
const current1 = document.querySelector("#current--0");
const NewgameEl = document.querySelector(".btn--new");
const scoreEl0 = document.querySelector("#score--0");
const scoreEl1 = document.querySelector("#score--1");
const btnholdEl = document.querySelector(".btn--hold");
const player0 = document.querySelector(".player--active");
const player1 = document.querySelector(".player--active");
const Main = document.querySelector("main");
/*function getRandomNonRepeatingNumber(min ,max, count){
    let numbers = [];
    for(let i = min; i <= max; i++){
     numbers.push(i);   
    }
    let result = [];
    for(let i = 0 ; i < count; i++){
        const randomIndex = Math.floor(Math.random() * numbers.length);
        const selectedNumber = numbers[randomIndex];
        result.push(selectedNumber);
        numbers.splice(randomIndex, 1);
    }

    return result;
}*/

/*const randomNumbers = getRandomNonRepeatingNumber(0, 1 ,1);
console.log(randomNumbers);*/

/*diceEl.src = "dice-1.png";*/
let currentScore = 0;
let playeractive = 0;
let isPlaying = true;
rolldiceEl.addEventListener('click', function(){
    if (isPlaying){
    const dice = Math.trunc(Math.random() * 6) + 1;
    diceEl.src = `dice-${dice}.png`;
 
    if(dice !== 1){
    currentScore += dice;
    document.querySelector(`#current--${playeractive}`).textContent = currentScore;
    
   }else{
   switchPlayer();
   }
}
}
);
const switchPlayer = function() {
    currentScore = 0;
    document.querySelector(`#current--${playeractive}`).textContent = 0;
    playeractive = playeractive === 0 ? 1 : 0;
    Main.children[0].classList.toggle("player--active");
    Main.children[1].classList.toggle("player--active");
  };



let scores = [0 , 0];

btnholdEl.addEventListener('click', function(){
 if (isPlaying){   
scores[playeractive] += currentScore;
document.querySelector(`#score--${playeractive}`).textContent = scores[playeractive];
if(scores[playeractive] > 10){
    document.querySelector(`player--${playeractive}`).classList.add('player--winner');
    isPlaying = false;
}

}

switchPlayer();
 }
);





NewgameEl.addEventListener('click', function(){
    document.querySelector(".current--score").textContent = 0;
    document.querySelector(".score").textContent = 0;

})

/*btnholdEl.addEventListener('click', function(){
   


    }
 

 scoreEl.textContent = sum;

)*/





